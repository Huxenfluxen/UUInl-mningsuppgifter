package napoleon;

public class CardOrderException extends Exception {
    public CardOrderException() {
        super();
    }
    public CardOrderException(String s) {
        super(s);
    }
}
